import java.util.*;

class Task1 {
    public List<LoanAccount> getOverdueLoans(List<LoanAccount> accounts) {
        List<LoanAccount> result = new ArrayList<>(); // FIX: initialize list

        if (accounts == null) return result; // FIX: null check

        Date today = new Date();

        for (LoanAccount account : accounts) {
            if (account == null) continue; // FIX: null account

            Date dueDate = account.getDueDate();
            if (dueDate == null) continue; // FIX: null dueDate

            if (dueDate.before(today) && account.getOutstandingBalance() > 0) {
                result.add(account);
            }
        }
        return result;
    }
}

class LoanAccount {
    private Date dueDate;
    private double outstandingBalance;
    private String accountId;

    public Date getDueDate() { return dueDate; }
    public double getOutstandingBalance() { return outstandingBalance; }
    public String getAccountId() { return accountId; }
}
