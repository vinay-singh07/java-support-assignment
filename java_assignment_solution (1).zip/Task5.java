import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class Task5 {

    private static final Logger logger = LoggerFactory.getLogger(Task5.class);

    public ValidationResult validate(Document doc) {
        try {
            if (doc == null) {
                logger.warn("Document is null"); // FIX: expected case
                return ValidationResult.invalid();
            }
            String content = doc.extractContent();
            if (content == null || content.isEmpty()) {
                logger.warn("Empty content"); // FIX: expected case
                return ValidationResult.invalid();
            }
            return runValidationRules(content);

        } catch (Exception e) {
            logger.error("Unexpected error during validation", e); // FIX
            return ValidationResult.invalid(); // FIX: avoid null
        }
    }

    public void validateBatch(List<Document> docs) {
        for (Document doc : docs) {
            try {
                ValidationResult r = validate(doc);
                if (r != null && r.isValid()) { // FIX: null safe
                    saveResult(r);
                }
            } catch (Exception e) {
                logger.error("Error processing document", e); // FIX: no swallowing
            }
        }
    }

    private ValidationResult runValidationRules(String content) { return new ValidationResult(true); }
    private void saveResult(ValidationResult r) {}
}

class Document {
    public String extractContent() { return ""; }
}

class ValidationResult {
    private boolean valid;
    public ValidationResult(boolean v) { this.valid = v; }
    public boolean isValid() { return valid; }

    public static ValidationResult invalid() {
        return new ValidationResult(false);
    }
}
