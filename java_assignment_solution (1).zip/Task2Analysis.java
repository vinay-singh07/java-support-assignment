public class Task2Analysis {

    // 1. Cause:
    // ConcurrentModificationException occurs when a collection is modified
    // while iterating over it using a fail-fast iterator.

    // 2. Likely issue:
    // Removing elements inside a for-each loop:
    // for (Transaction t : list) {
    //     list.remove(t);
    // }

    // 3. Fix:
    // Use Iterator remove():
    // Iterator<Transaction> it = list.iterator();
    // while (it.hasNext()) {
    //     Transaction t = it.next();
    //     if (condition) {
    //         it.remove();
    //     }
    // }
}
