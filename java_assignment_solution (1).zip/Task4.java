import java.sql.*;
import java.util.*;
import javax.sql.DataSource;

class Task4 {

    private DataSource dataSource;

    public List<ReportEntry> fetchMonthlyReport(String accountId, int month, int year) throws SQLException {

        List<ReportEntry> entries = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM report_entries WHERE account_id = ? AND MONTH(entry_date) = ? AND YEAR(entry_date) = ?")) {

            ps.setString(1, accountId);
            ps.setInt(2, month);
            ps.setInt(3, year);

            try (ResultSet rs = ps.executeQuery()) { // FIX: close ResultSet
                while (rs.next()) {
                    entries.add(mapRow(rs));
                }
            }
        } // FIX: connection & statement auto-closed

        return entries;
    }

    private ReportEntry mapRow(ResultSet rs) { return null; }
}

class ReportEntry {}
